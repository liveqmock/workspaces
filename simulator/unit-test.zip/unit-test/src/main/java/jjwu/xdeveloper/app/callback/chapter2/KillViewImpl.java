package jjwu.xdeveloper.app.callback.chapter2;

public abstract class KillViewImpl {
	
	public void confirm(){
		System.out.println("封杀帐号成功!");
	}
	
	public abstract void confrimEvent1();
	
	public abstract void confrimEvent2();

}
