package jjwu.xdeveloper.app.callback.chapter1;

public interface Event {

}
