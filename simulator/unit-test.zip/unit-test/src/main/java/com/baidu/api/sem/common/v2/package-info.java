@javax.xml.bind.annotation.XmlSchema(namespace = "http://api.baidu.com/sem/common/v2", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.baidu.api.sem.common.v2;
